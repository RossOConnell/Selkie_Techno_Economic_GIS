function check_for_float(text, minimum, maximum) {


    let trimmed_text = text.trim();
    if (trimmed_text === "") {
        return " Value required";
    }
    let number = parseFloat(trimmed_text);
    if (isNaN(number)) {
        return " Numbers only";
    }
    if (number < minimum) {
        return " Minimum: " + minimum;
    }
    if (number > maximum) {
        return " Maximum: " + maximum;
    }
    return "";
}


function calc_te() {
    console.log("calculate_lcoe")
    let defaultProjectLife_error_message = check_for_float(defaultProjectLife.value, 1, 100);
    let defaultDiscountRate_error_message = check_for_float(defaultDiscountRate.value, 1, 50);
    if (defaultProjectLife_error_message || defaultDiscountRate_error_message) {
        defaultProjectLife_errors.innerHTML = defaultProjectLife_error_message;
        defaultDiscountRate_errors.innerHTML = defaultDiscountRate_error_message;
    } else {
        lcoe.value = defaultProjectLife.value / (defaultDiscountRate.value * defaultDiscountRate.value);
    }
}


require([
    "esri/Map",
    "esri/views/MapView",
    "esri/widgets/BasemapToggle",
    "esri/layers/GroupLayer",
    "esri/layers/FeatureLayer",
    "esri/layers/MapImageLayer",
    "esri/widgets/LayerList",
    "esri/widgets/Legend",
    "esri/renderers/visualVariables/ColorVariable",
    "esri/widgets/DistanceMeasurement2D",
    "esri/widgets/AreaMeasurement2D",
    "esri/PopupTemplate",
    "esri/tasks/QueryTask",
    "esri/Graphic",
    "esri/tasks/support/Query",
    "esri/tasks/support/StatisticDefinition"

], function (
    Map,
    MapView,
    BasemapToggle,
    GroupLayer,
    FeatureLayer,
    MapImageLayer,
    LayerList,
    Legend,
    ColorVariable,
    DistanceMeasurement2D,
    AreaMeasurement2D,
    popupTemplate,
    QueryTask,
    Graphic,
    Query,
    StatisticDefinition


) {



    var activeWidget = null;


    // var template = {
    //     title:
    //         "<h3>Techno-Economic Calculator</h3>",

    //     content:
    //         "<p><b>Spatial</b>" + "<BR>" +
    //         "Annual Energy Production: <b>{WavePower}</b> kW/m" + "<BR>" +
    //         "Distance to nearest MRE Port: <b>{Distance_t}</b> km" + "<BR>" +
    //         "Distance to nearest Grid Access Point: <b>{Distance_t}</b> km" + "<BR>" + "<BR>" +
    //         "<b>Financial</b>" + "<BR>" +
    //         "Project Life: <b>" + "user-input" + "</b>  years " + "<BR>" +
    //         "Discount rate: <b>" + "user-input" + "</b>  % " + "<BR>" +
    //         "Capital Cost: <b>" + "user-input" + "</b>  €/kW-yr" + "<BR>" +
    //         "Fixed O&M: <b>" + "user-input" + "</b>  €/kW" + "<BR>" +
    //         "Variable O&M: <b>" + "user-input" + "</b>  €/kWh" + "<BR>" + "<BR>" +
    //         "<b>Results</b>" + "<BR>" +
    //         "LCoE: <b>" + "undefinded" + "</b> cents/kWh" + "<BR>" +
    //         "NPV: <b>" + "undefinded" + "</b> M€" + "<BR>" +
    //         "IRR: <b>" + "undefinded" + "</b> %" + "<BR></p>"

    // };

    // content: [
    //         {
    //             // It is also possible to set the fieldInfos outside of the content
    //             // directly in the popupTemplate. If no fieldInfos is specifically set
    //             // in the content, it defaults to whatever may be set within the popupTemplate.
    //             type: "fields",
    //             fieldInfos: [
    //                 {
    //                     fieldName: "WavePower",
    //                     tooltip: "Win percentage",
    //                     label: "AEP"
    //                 },
    //                 {
    //                     fieldName: "Distance_t",
    //                     label: "Distance to Port",
    //                 }
    //             ]
    //         }
    //     ]


    var defaultSym = {
        type: "simple-fill", // autocasts as new SimpleFillSymbol()
        outline: {
            // autocasts as new SimpleLineSymbol()
            color: [128, 128, 128, 0.2],
            width: "0.5px"
        }
    };

    var razorBill = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/razorbill_uk_and_eire_95_utilisation_distributions_in_5_bands_shp/FeatureServer",
        title: "Razorbill",
        visible: false,
        opacity: 0.75,
        renderer: {
            type: "simple",
            symbol: defaultSym,
            visualVariables: [
                {
                    type: "color",
                    field: "level_",
                    legendOptions: {
                        title: "Razorbill Density"
                    },
                    stops: [
                        {
                            value: 0.95,
                            color: "#350242",
                            label: "<5%"
                        },
                        {
                            value: 0.05,
                            color: "#FFFCD4",
                            label: ">95%"
                        }
                    ]
                }
            ]
        }
    });

    var europeanShag = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/european_shag_uk_and_eire_95_utilisation_distributions_in_5_bands/FeatureServer",
        title: "European Shag",
        visible: false,
        opacity: 0.5,
        renderer: {
            type: "simple",
            symbol: defaultSym,
            visualVariables: [
                {
                    type: "color",
                    field: "level_",
                    legendOptions: {
                        title: "European Shag Density"
                    },
                    stops: [
                        {
                            value: 0.95,
                            color: "#350242",
                            label: "<5%"
                        },
                        {
                            value: 0.05,
                            color: "#FFFCD4",
                            label: ">95%"
                        }
                    ]
                }
            ]
        }
    });

    var commonGuillemot = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/common_guillemot_uk_and_eire_95_utilisation_distributions_in_5_bands/FeatureServer",
        title: "Guillemot",
        visible: false,
        opacity: 0.5,
        renderer: {
            type: "simple",
            symbol: defaultSym,
            visualVariables: [
                {
                    type: "color",
                    field: "level_",
                    legendOptions: {
                        title: "Guillemot Density"
                    },
                    stops: [
                        {
                            value: 0.95,
                            color: "#350242",
                            label: "<5%"
                        },
                        {
                            value: 0.05,
                            color: "#FFFCD4",
                            label: ">95%"
                        }
                    ]
                }
            ]
        }
    });

    var blackleggedKittiwake = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/blacklegged_kittiwake_uk_and_eire_95_utilisation_distributions_in_5_bands/FeatureServer",
        title: "Black Legged Kittiwake",
        visible: false,
        opacity: 0.50,
        renderer: {
            type: "simple",
            symbol: defaultSym,
            visualVariables: [
                {
                    type: "color",
                    field: "level_",
                    legendOptions: {
                        title: "Black Legged Kittiwake Density"
                    },
                    stops: [
                        {
                            value: 0.95,
                            color: "#350242",
                            label: "<5%"
                        },
                        {
                            value: 0.05,
                            color: "#FFFCD4",
                            label: ">95%"
                        }
                    ]
                }
            ]
        }
    });


    var seabirdGroupLayer = new GroupLayer({
        title: "Seabird Distributions",
        visible: true,
        visibilityMode: "inclusive",
        layers: [razorBill, europeanShag, commonGuillemot, blackleggedKittiwake],
    });




    var marineConservationZones = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/mcz_uk/FeatureServer",
        title: "Marine Conservation Zones",
        visible: false,
        opacity: 0.25,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "yellow"
            }
        }
    });

    var marineSPAs = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/marine_and_coastal_spas_irlanduk/FeatureServer",
        title: "Coastal and Marine SPAs",
        visible: false,
        opacity: 0.25,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "mediumorchid"
            }
        }
    });

    var marineSACs = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/marine_and_coastal_sacs_irlanduk_/FeatureServer",
        title: "Coastal and Marine SACs",
        visible: false,
        opacity: 0.25,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "salmon"
            }
        }
    });

    var protectedSitesGroupLayer = new GroupLayer({
        title: "Protected Sites",
        visible: true,
        visibilityMode: "inclusive",
        layers: [marineConservationZones, marineSPAs, marineSACs]
    });

    var environmentGroupLayer = new GroupLayer({
        title: "Environment",
        visible: true,
        visibilityMode: "inclusive",
        layers: [seabirdGroupLayer, protectedSitesGroupLayer],
    });



    var seabedSubstrate = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/Seabed_Substrate_UKandIRL/FeatureServer",
        title: "Seabed Substrate",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                outline: {
                    width: 0
                }
            },
            visualVariables: [
                {
                    type: "color",
                    field: "Folk_7cl",
                    legendOptions: {
                        title: "Seabed Substrate/Geology (Folk-7 scale)",
                        showLegend: true,
                    },
                    stops: [
                        {
                            value: 2,
                            color: "#d9d78c",
                            label: "Sand"
                        },
                        {
                            value: 3,
                            color: "#72231f",
                            label: "Coarse Sediment"
                        },
                        {
                            value: 4,
                            color: "#a664a0",
                            label: "Mixed Sediment"
                        },
                        {
                            value: 5,
                            color: "#454f4b",
                            label: "Rock & Boulders"
                        },
                        {
                            value: 11,
                            color: "#75351e",
                            label: "Mud"
                        },
                        {
                            value: 12,
                            color: "#99905c",
                            label: "Sandy Mud"
                        },
                        {
                            value: 13,
                            color: "#dbb658",
                            label: "Muddy Sand"
                        }

                    ]
                }
            ]
        },
        popupTemplate: {
            title: "Seabed Substrate/Geology",
            content:
                "Classification: <b>{Folk_7cl_t}</b>"
        },
    });


    var seabedGroupLayer = new GroupLayer({
        title: "Seabed",
        visible: true,
        visibilityMode: "inclusive",
        layers: [seabedSubstrate],
    });





    var fishingDensity = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/Fish_poly__erase_10pc/FeatureServer",
        title: "Fishing Vessel Density (AIS)",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                outline: {
                    width: 0
                }
            },
            visualVariables: [
                {
                    type: "color",
                    field: "gridcode",
                    legendOptions: {
                        title: "Fishing Vessel Density (hours/km2/month)"
                    },
                    stops: [
                        {
                            value: 394758,
                            color: "#ffffb2",
                            label: "10%"
                        },
                        {
                            value: 785508,
                            color: "#fd8d3c",
                            label: "5%"
                        }

                    ]
                }
            ]
        },
    });

    // var fishingDensity = new FeatureLayer({
    //     url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/Fish_point_erase_5pc/FeatureServer",
    //     title: "Fishing Vessel Density (AIS)",
    //     visible: false,
    //     opacity: 1,
    //     renderer: {
    //         type: "heatmap",
    //         blurRadius: 5,
    //         colorStops: [
    //             { color: "rgba(63, 40, 102, 0)", value: 0 },
    //             { color: "#472b77", value: 0.083 },
    //             { color: "#7b3ce9", value: 0.581 },
    //             { color: "#ffff00", value: 1 }
    //         ],
    //         maxPixelIntensity: 25,
    //         minPixelIntensity: 0
    //     }
    // });

    var shippingDensity = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/Ship_poly_erase_10pc/FeatureServer",
        title: "Shipping Traffic Density (AIS)",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                outline: {
                    width: 0
                }
            },
            visualVariables: [
                {
                    type: "color",
                    field: "gridcode",
                    legendOptions: {
                        title: "Shipping Traffic Density (hours/km2/month)"
                    },
                    stops: [

                        {
                            value: 1424265,
                            color: "#ffffb2",
                            label: "10%"
                        },
                        {
                            value: 2961363,
                            color: "#fd8d3c",
                            label: "5%"
                        }
                    ]
                }
            ]
        },
    });



    var trafficGroupLayer = new GroupLayer({
        title: "Marine Traffic",
        visible: true,
        visibilityMode: "inclusive",
        layers: [fishingDensity, shippingDensity],
    });



    var eireTerritorialSea = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/irl_territorial_sea/FeatureServer",
        title: "Ireland's Territorial Seas",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "limegreen",
            }
        }
    });

    var ukTerritorialSea = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/uk_territorial_sea_limit/FeatureServer",
        title: "UK's Territorial Seas",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "orange",
            }
        }
    });

    var isleOfManTerritorialSea = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/isle_of_man_territorial_sea/FeatureServer",
        title: "Isle of Man's Territorial Seas",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "sienna",
            }
        }
    });

    var selkieArea = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/EU_IRL_WAL_Region/FeatureServer",
        title: "Selkie Project Area",
        visible: true,
        opacity: 0.45,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "teal",
                outline: {
                    // autocasts as new SimpleLineSymbol()
                    color: "yellow",
                    width: "1.25px",
                }
            }
        }
    });



    var localSeaAreas = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/selkieseaareascombined/FeatureServer",
        title: "Local Sea Areas",
        visible: false,
        opacity: 0.15,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "teal",
                outline: {
                    // autocasts as new SimpleLineSymbol()
                    color: "yellow",
                    width: "1.25px",
                }
            }
        }
    });



    var marinePlanAreaWales = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/marine_plan_areas_wales_line_erase/FeatureServer",
        title: "Wales' Marine Plan Area",
        visible: true,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "grey",
            }
        }
    });

    var marinePlanAreaIreland = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/irl_mpa_line/FeatureServer",
        title: "Ireland's Marine Plan Area",
        visible: true,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "grey",
            }
        }
    });

    var eezUkandIrl = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/eez_irl_and_uk_complete/FeatureServer",
        title: "EEZ Limits (Eire and UK)",
        visible: true,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "transparent",
                outline: {
                    // autocasts as new SimpleLineSymbol()
                    color: "red",
                    width: "1px"
                }
            }
        }
    });



    var administrativGroupLayer = new GroupLayer({
        title: "Administrative",
        visible: true,
        visibilityMode: "inclusive",
        layers: [eireTerritorialSea, ukTerritorialSea, isleOfManTerritorialSea, localSeaAreas, selkieArea, marinePlanAreaWales, marinePlanAreaIreland, eezUkandIrl],
    });



    var ukWaveDeploymentSite = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/offshore_wave_site_agreements_england_wales__ni_the_crown_estate_without_marker_buoys/FeatureServer",
        title: "UK Wave Energy Site Agreements",
        visible: false,
        opacity: 0.8,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "transparent",
                outline: {
                    // autocasts as new SimpleLineSymbol()
                    color: "seagreen",
                    width: "1px"
                }
            }
        }
    });

    var ukTidalDeploymentSite = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/offshore_tidal_stream_site_agreements_england_wales__ni_the_crown_estate/FeatureServer",
        title: "UK Tidal Stream Site Agreements",
        visible: false,
        opacity: 0.8,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "transparent",
                outline: {
                    // autocasts as new SimpleLineSymbol()
                    color: "blueviolet",
                    width: "1px"
                }
            }
        }
    });

    var westWaveDeploymentSite = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/westwave_wec_deployment_zone/FeatureServer",
        title: "WestWave - Proposed Deployment Site",
        visible: false,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "transparent",
                outline: {
                    // autocasts as new SimpleLineSymbol()
                    color: "steelblue",
                    width: "1px"
                }
            }
        }
    });

    var westWaveCableCorridor = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/westwave_cable_corridor_zone/FeatureServer",
        title: "WestWave - Poposed Cable Route Corridor",
        visible: false,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                color: "transparent",
                outline: {
                    // autocasts as new SimpleLineSymbol()
                    color: "green",
                    width: "1px"
                }
            }
        }
    });


    var oreInfrastructureGroupLayer = new GroupLayer({
        title: "Sites of Interest",
        visible: true,
        visibilityMode: "inclusive",
        layers: [ukWaveDeploymentSite, ukTidalDeploymentSite, westWaveDeploymentSite, westWaveCableCorridor],
    });




    var cableRoutes = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/kisorca_subsea_pipelines_cables/FeatureServer",
        title: "Sub-Sea Cable Routes",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "red",
            }
        }
    });

    var roadNetwork = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/roadnetwork_eire_and_uk/FeatureServer",
        title: "Major Road Network",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "seagreen",
            }
        }
    });

    var railNetwork = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/railnetwork_eire_and_ukshp/FeatureServer",
        title: "Rail Network",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "darkgoldenrod",
            }
        }
    });

    var ferryRoutes = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/ferryroutes_selkieseas/FeatureServer",
        title: "Ferry Routes",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-line",
                color: "dodgerblue",
            }
        }
    });

    var airportsIrlUk = new FeatureLayer({
        url: "https://services5.arcgis.com/r459PoGVE2A4yVk7/arcgis/rest/services/airfields_eire_and_uk/FeatureServer",
        title: "Airports",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-marker", // autocasts as new SimpleMarkerSymbol()
                color: "mediumpurple",
                outline: {
                    color: [255, 255, 255, 0.7],
                    width: 0.5
                },
                size: 7.5
            }
        }
    });

    var coastalSubstationsIrlUKDistance = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/Coastal_Subtations_Proxim/FeatureServer",
        popupTemplate: {
            title: "Distance to closest Grid Connection",
            content: function () {
                return "{distance} km"
            }
        },
        title: "Grid Connection Proximity",
        visible: false,
        opacity: 0.65,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                outline: {
                    width: 0
                }
            },
            visualVariables: [
                {
                    type: "color",
                    field: "distance",
                    legendOptions: {
                        title: "Distance (km)"
                    },
                    stops: [
                        {
                            value: 0,
                            color: "#ff6600",
                            label: "0"
                        },
                        {
                            value: 100,
                            color: "#0066ff",
                            label: "100"
                        }
                    ]
                }
            ]
        }
    });



    var coastalSubstationsIrlUK = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/Coastal_Subtations_UKandIrl/FeatureServer",
        title: "Coastal Electrical Substations",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-marker", // autocasts as new SimpleMarkerSymbol()
                color: "darkorange",
                outline: {
                    color: [255, 255, 255, 0.7],
                    width: 0.5
                },
                size: 7.5
            }
        }
    });


    var mrePortsEireCymruDistance = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/MRE_Ports_IRLandWAL_Proxim/FeatureServer",
        popupTemplate: {
            title: "Distance to closest Port",
            content: function () {
                return "{distance} km"
            }
        },
        title: "MRE Port Proximity",
        visible: false,
        opacity: 0.65,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                outline: {
                    width: 0
                }
            },
            visualVariables: [
                {
                    type: "color",
                    field: "distance",
                    legendOptions: {
                        title: "Distance (km)"
                    },
                    stops: [
                        {
                            value: 0,
                            color: "#00ffff",
                            label: "0"
                        },
                        {
                            value: 100,
                            color: "#3333cc",
                            label: "100"
                        }
                    ]
                }
            ]
        }
    });


    var mrePortsEireCymru = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/Potential_MRE_Ports_IRL_and_WAL/FeatureServer",
        title: "Ports with MRE capabilities (Eire and Cymru only)",
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-marker", // autocasts as new SimpleMarkerSymbol()
                color: "darkturquoise",
                outline: {
                    color: [255, 255, 255, 0.7],
                    width: 0.5
                },
                size: 7.5
            }
        }
    });

    var infrastructureGroupLayer = new GroupLayer({
        title: "Infrastructure",
        visible: true,
        visibilityMode: "inclusive",
        layers: [roadNetwork, railNetwork, ferryRoutes, cableRoutes, airportsIrlUk, coastalSubstationsIrlUKDistance, coastalSubstationsIrlUK, mrePortsEireCymruDistance, mrePortsEireCymru],
    });





    var template = {

        title: '<h3><b><u>Techno-Economic Calculator</b></u></h3>' + '<BR>' +
            'Annual Energy Production: <u>{WavePower}</u> kW/m' + '<BR>',

        content:

            buildPopupContent(meanAnnualWaveResourceIrl)
    };



    var meanAnnualWaveResourceIrl = new FeatureLayer({
        url: "https://services6.arcgis.com/59pPgTnLCRBan6mn/arcgis/rest/services/GlobalResource_with_Ports/FeatureServer",
        title: "Ireland's Wave Energy Resource (kW/m)",
        outFields: ["WavePower"],
        visible: false,
        opacity: 1,
        renderer: {
            type: "simple",
            symbol: {
                type: "simple-fill",
                outline: {
                    width: 0
                }
            },
            visualVariables: [
                {
                    type: "color",
                    field: "WavePower",

                    legendOptions: {
                        title: "Resource (kW/m)"
                    },
                    stops: [
                        {
                            value: 0,
                            color: "#ffe3aa",
                            label: "0"
                        },
                        {
                            value: 20,
                            color: "#ffaa00",
                            label: "20"
                        },
                        {
                            value: 40,
                            color: "#ff3900",
                            label: "40"
                        },
                        {
                            value: 60,
                            color: "#d50621",
                            label: "60"
                        },
                        {
                            value: 80,
                            color: "#801164",
                            label: "80"
                        },
                        {
                            value: 100,
                            color: "#2b1ca7",
                            label: "100"
                        }
                    ]
                }
            ]
        },
        popupTemplate: template
    });


    // content:
    //     "<p><b>Spatial</b>" + "<BR>" +
    //     "Annual Energy Production: <b>{WavePower}</b> kW/m" + "<BR>" +
    //     "Distance to nearest MRE Port: <b>{Distance_t}</b> km" + "<BR>" +
    //     "Distance to nearest Grid Access Point: <b>{Distance_t}</b> km" + "<BR>" + "<BR>" +
    //     "<b>Financial</b>" + "<BR>" +
    //     "Project Life: <b>" +  + "</b>  years " + "<BR>" +
    //     "Discount rate: <b>" + testSpan + "</b>  % " + "<BR>" +
    //     "Capital Cost: <b>" + "input" + "</b>  €/kW-yr" + "<BR>" +
    //     "Fixed O&M: <b>" + "input" + "</b>  €/kW" + "<BR>" +
    //     "Variable O&M: <b>" + "input" + "</b>  €/kWh" + "<BR>" + "<BR>" +
    //     "<b>Results</b>" + "<BR>" +
    //     "LCoE: <b>" + "undefinded" + "</b> cents/kWh" + "<BR>" +
    //     "NPV: <b>" + "undefinded" + "</b> cents/kWh" + "<BR>" +
    //     "IRR: <b>" + "undefinded" + "</b> cents/kWh" + "<BR></p>"


    

    function buildPopupContent() {

        var aep = [
            {
                'featureLayer': meanAnnualWaveResourceIrl,
                'fieldInfos': [
                    {
                        'fieldName': 'WavePower',
                    }
                ]
            }
        ];


        console.log("buildPopupContent")

        

        let div = document.createElement("div");

        div.innerHTML =


            '<table><tr><td>AEP: <td>' + aep + '</td></tr>' +
            '<tr><td>Project Life: <td><input type="number" name="defaultProjectLife" id="defaultProjectLife" style="width: 7em" value="20" min=1 max=100/><span id="defaultProjectLife_errors"></span></td></tr>' +
            '<tr><td>Discount Rate: <td><input type="number" name="defaultDiscountRate" id="defaultDiscountRate" style="width: 7em" value="5" min=1 max=50/><span id="defaultDiscountRate_errors"></span></td></tr></table>' + '<BR>' +
            // '<tr><td>Capital Costs: <td><input id="capitalID" value="' + defaultCapital + '" type="number" name="capitalCost"> €</td></tr>' +
            // '<tr><td>O&M Costs: <td><input id="vomID" value="' + defaultOM + '" type="number" name="omCosts"> €/yr</td></tr></table><BR>' +

            // '<div id="calculate_lcoe"><input type="submit" name="submit"/></div>' +
            '<div id="calculate_lcoe"><button onclick="calc_te()">Calculate</button></div>' + '<BR>' +
            '<button></div>' +
            // <button onclick="myFunction()">Click me</button> +
            // '<h5><b>Results</b></h5>' +
            '<table><tr><td>LCOE: <td><input type="text" name="lcoe" id="lcoe" style="width: 7em" disabled /></td></tr></table>'
        // '<tr><td>NPV: <td><input id="discountID" value="' + defaultResult + '" type="number" name="discountRate"> M€</td></tr>' +
        // '<tr><td>IRR: <td><input id="vomID" value="' + defaultResult + '" type="number" name="omCosts"> %</td></tr></table><BR>'

        return div;

    }




    var resourceGroupLayer = new GroupLayer({
        title: "Renewable Energy Resources (Techno-Economic Calculator)",
        visible: true,
        visibilityMode: "inclusive",
        layers: [meanAnnualWaveResourceIrl],
    });



    var map = new Map({
        basemap: "oceans",
        layers: [resourceGroupLayer, oreInfrastructureGroupLayer, infrastructureGroupLayer, trafficGroupLayer, seabedGroupLayer, environmentGroupLayer, administrativGroupLayer]
    });

    var view = new MapView({
        container: "viewDiv",
        map: map,
        center: [-5, 52.50],
        zoom: 6.25,
        padding: {
            top: 85
        }
    });



    var basemapToggle = new BasemapToggle({
        view: view,
        nextBasemap: "hybrid"
    });


    var coordsWidget = document.createElement("div");
    coordsWidget.id = "coordsWidget";
    coordsWidget.className = "esri-widget esri-component";
    coordsWidget.style.padding = "7px 15px 5px";
    coordsWidget.style.backgroundColor = "white";


    function showCoordinates(pt) {
        var coords = "Lat/Lon " + pt.latitude.toFixed(3) + " " + pt.longitude.toFixed(3);
        coordsWidget.innerHTML = coords;
    }

    view.watch(["stationary"], function () {
        showCoordinates(view.center);
    });

    //*** Add event to show mouse coordinates on click and move ***//
    view.on(["pointer-down", "pointer-move"], function (evt) {
        showCoordinates(view.toMap({ x: evt.x, y: evt.y }));
    });




    function defineActions(event) {

        var item = event.item;


        if (item.layer.type != "group") {
            item.panel = {
                content: "legend",
                open: false
            }
        }

        if (item.title === "Ireland's Wave Energy Resource (kW/m)") {

            item.actionsSections = [
                [
                    {
                        title: "Go to full extent",
                        className: "esri-icon-zoom-out-fixed",
                        id: "full-extent"
                    },
                    {
                        title: "Layer information",
                        className: "esri-icon-description",
                        id: "information"
                    }
                ],
                [
                    {
                        title: "Increase opacity",
                        className: "esri-icon-up",
                        id: "increase-opacity"
                    },
                    {
                        title: "Decrease opacity",
                        className: "esri-icon-down",
                        id: "decrease-opacity"
                    }
                ]
            ];
        }
    }


    view.when(function () {
        // Create the LayerList widget with the associated actions
        // and add it to the top-right corner of the view.
        var layerList = new LayerList({
            view: view,
            listItemCreatedFunction: defineActions
        });

        // executes for each ListItem in the LayerList

        // Event listener that fires each time an action is triggered

        layerList.on("trigger-action", function (event) {
            // The layer visible in the view at the time of the trigger.


            // Capture the action id.
            var id = event.action.id;

            if (id === "full-extent") {
                // if the full-extent action is triggered then navigate
                // to the full extent of the visible layer
                view.goTo(meanAnnualWaveResourceIrl.fullExtent).catch(function (error) {
                    if (error.name != "AbortError") {
                        console.error(error);
                    }
                });
            } else if (id === "information") {
                // if the information action is triggered, then
                // open the item details page of the service layer
                window.open(meanAnnualWaveResourceIrl.url);
            } else if (id === "increase-opacity") {
                // if the increase-opacity action is triggered, then
                // increase the opacity of the GroupLayer by 0.25

                if (meanAnnualWaveResourceIrl.opacity < 1) {
                    meanAnnualWaveResourceIrl.opacity += 0.25;
                }
            } else if (id === "decrease-opacity") {
                // if the decrease-opacity action is triggered, then
                // decrease the opacity of the GroupLayer by 0.25

                if (meanAnnualWaveResourceIrl.opacity > 0) {
                    meanAnnualWaveResourceIrl.opacity -= 0.25;
                }
            }

        });


        document
            .getElementById("distanceButton")
            .addEventListener("click", function () {
                setActiveWidget(null);
                if (!this.classList.contains("active")) {
                    setActiveWidget("distance");
                } else {
                    setActiveButton(null);
                }
            });

        document
            .getElementById("areaButton")
            .addEventListener("click", function () {
                setActiveWidget(null);
                if (!this.classList.contains("active")) {
                    setActiveWidget("area");
                } else {
                    setActiveButton(null);
                }
            });

        function setActiveWidget(type) {
            switch (type) {
                case "distance":
                    activeWidget = new DistanceMeasurement2D({
                        view: view
                    });

                    // skip the initial 'new measurement' button
                    activeWidget.viewModel.newMeasurement();

                    view.ui.add(activeWidget, "top-left");
                    setActiveButton(document.getElementById("distanceButton"));
                    break;
                case "area":
                    activeWidget = new AreaMeasurement2D({
                        view: view
                    });

                    // skip the initial 'new measurement' button
                    activeWidget.viewModel.newMeasurement();

                    view.ui.add(activeWidget, "top-left");
                    setActiveButton(document.getElementById("areaButton"));
                    break;
                case null:
                    if (activeWidget) {
                        view.ui.remove(activeWidget);
                        activeWidget.destroy();
                        activeWidget = null;
                    }
                    break;
            }
        }

        function setActiveButton(selectedButton) {
            // focus the view to activate keyboard shortcuts for sketching
            view.focus();
            var elements = document.getElementsByClassName("active");
            for (var i = 0; i < elements.length; i++) {
                elements[i].classList.remove("active");
            }
            if (selectedButton) {
                selectedButton.classList.add("active");
            }
        }

        view.ui.add(basemapToggle, "top-left");
        view.ui.add(coordsWidget, "bottom-left");
        view.ui.add(layerList, "top-right");
        view.ui.add("toolbar", "top-left");

    });
});
